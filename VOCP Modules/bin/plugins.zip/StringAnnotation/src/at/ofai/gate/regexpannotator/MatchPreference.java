/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package at.ofai.gate.regexpannotator;

/**
 *
 * @author Johann Petrak <johann.petrak@jpetrak.com>
 */
public enum MatchPreference {
  ALL, FIRSTRULE, LASTRULE, LONGEST_FIRSTRULE, LONGEST_LASTRULE, LONGEST_ALLRULES
}
