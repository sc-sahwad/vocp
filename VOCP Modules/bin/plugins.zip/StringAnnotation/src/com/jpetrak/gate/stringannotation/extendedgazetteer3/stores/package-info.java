/**
 * 
 */
/**
 * @author Johann Petrak
 *
 */
package com.jpetrak.gate.stringannotation.extendedgazetteer3.stores;